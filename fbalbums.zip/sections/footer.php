<script
        src="https://code.jquery.com/jquery-3.2.1.min.js"
        integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
        crossorigin="anonymous"></script>
<script src="bootstrap-3.3.7/js/bootstrap.min.js"></script>
<script async src="js/script.js"></script>
</body>
</html>